export function Beam() {
  return (
    <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-rose-500 to-transparent opacity-50" />
  )
}
